﻿namespace $safeprojectname$
{
  public struct Constants
  {
    public struct LayoutParameters
    {
      public static string IsFluid => "ContainerIsFluid";
      public static string UseStaticPlaceholderNames => "UseStaticPlaceholderNames";
    }
  }
}